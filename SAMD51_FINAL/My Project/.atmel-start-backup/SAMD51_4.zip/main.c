#include <atmel_start.h>
#include <stdio.h>
#include <hal_delay.h>

#include "Apps/UsartDebug/usartDebug.h"
#include "Apps/LedControl/include/ledControl.h"

uint8_t printBuff[30];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1)
	{
		sprintf(printBuff,"UART Debugging Enabled \r\n");
		usartDebugPrint((uint8_t*)printBuff,sizeof(printBuff));
		//led_PeformLedTest();
		delay_ms(2000);
	}
}
