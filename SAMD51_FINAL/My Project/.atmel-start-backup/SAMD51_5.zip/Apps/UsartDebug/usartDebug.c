/*
 * usartDebug.c
 *
 * Created: 4/14/2018 12:54:34 PM
 *  Author: anilj
 */ 
#include "driver_init.h"
#include "utils.h"

static int32_t ReadResponseFromTerminal(uint8_t *RecvdData,const int32_t length);

void usartDebugPrint(const uint8_t *const dataToPrint,const uint16_t length)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&USART_1, &io);
	usart_sync_enable(&USART_1);
	
	io_write(io, dataToPrint, length);
}

void usartWriteReadTest(void)
{
#if 0
	uint8_t printBuff[50];
	uint8_t readBuff[5];
	uint32_t readcnt;
	
	sprintf(printBuff,"Enter Your Name \r\n");
	usartDebugPrint((uint8_t*)printBuff,sizeof(printBuff));
	
	readcnt = ReadResponseFromTerminal(readBuff,5);
	sprintf(printBuff,"Read %d char from Terminal.\r\n\n",readcnt);
	usartDebugPrint(printBuff,sizeof(printBuff));
	
	sprintf(printBuff,"Hi %s, How r u?\r\n",readBuff);
	usartDebugPrint(printBuff,sizeof(printBuff));
#endif
	
	//vTaskDelay(2000);	
}

static int32_t ReadResponseFromTerminal(uint8_t *RecvdData,const int32_t length)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&USART_1, &io);
	usart_sync_enable(&USART_1);
	
	return io_read(io,RecvdData,length);
}