/*
 * usartDebug.h
 *
 * Created: 4/14/2018 12:54:50 PM
 *  Author: anilj
 */ 


#ifndef USARTDEBUG_H_
#define USARTDEBUG_H_

void usartDebugPrint(const uint8_t *const dataToPrint,const uint16_t length);

void usartWriteReadTest(void);


#endif /* USARTDEBUG_H_ */